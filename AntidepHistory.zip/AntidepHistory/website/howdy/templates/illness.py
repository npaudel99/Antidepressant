#!/usr/bin/env python
import cgi
import cgitb; cgitb.enable()  # for troubleshooting

print ("""
<html>

<head><title>Illness</title>
<style>
         h2 {
        background-color: aquamarine;
        width: 1430px;
        border:cadetblue 15px;
        padding : 20px;
        margin: 20px;
        text-align: center
    }
    body {
    background-color: rgb(23, 233, 149);
    }
    p.sans-serif {
        font-family: Arial, Helvetica, sans-serif
    }
    </style>
<h2 class="serif"; style="text-align:left""color:rgb(128, 168, 207);"> Medical History Taking: </h2><br />

</head>

<body>


""")

form = cgi.FieldStorage()
message = form.getvalue("message", "(no message)")
import sqlite3
conn = sqlite3.connect('Users/namratapaudel/Documents/Portal/website/ANTI_DEP.db',isolation_level=None)
#conn = sqlite3.connect('ANTI_DEP.db',isolation_level=None)

conn.execute("INSERT INTO USER(gender) VALUES ('%s')" % (message) )
try:
    cursor=conn.cursor()
    cursor.execute("SELECT MAX(USER_ID) FROM USER")
    result_set = cursor.fetchall()
    for row in result_set:
        uid =  row[0]
        #Set-Cookie: userid = uid
except maxUserError: print ("Location:   Users/namratapaudel/Documents/Portal/website/howdyfinish.html\r\n\r" )

print ("""
  <h1 class="sans-serif"; style="font-family:Arial, Helvetica, sans-serif"> Using one word, please tell me about an illness, struggle with alcohol/drugs, or a mental health problem you have had..</h1>

  <form method="post" action="confirmResponse.py">
     <input type="hidden" name="id" value= "%s"/>
    <p class="sans-serif"; style="font-family:Arial, Helvetica, sans-serif"> Response: <input type="text" name="message"/></p>
     <br/><input type = "submit" value = "Submit" />
  </form>
</body>

</html>
""" % uid)
