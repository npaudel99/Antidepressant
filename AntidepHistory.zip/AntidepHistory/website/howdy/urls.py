# howdy/urls.py
from django.conf.urls import url
from howdy import views


urlpatterns = [
    url(r'^$', views.HomePageView.as_view()),
    url(r'^start.html', views.StartPageView.as_view()),
    url(r'^illness.html', views.illnesspageView.as_view()),
        url(r'^illness.py', views.IllnessPyView.as_view()),
    url(r'^ResponseFile.html', views.ResponseFileView.as_view()),
    url(r'^FinalMedication.html', views.FinalMedicationView.as_view()),
    url(r'^OtherIllness.html', views.OtherIllnessView.as_view()),
    ]
